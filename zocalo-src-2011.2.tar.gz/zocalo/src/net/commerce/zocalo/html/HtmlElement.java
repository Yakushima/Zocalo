package net.commerce.zocalo.html;

// Copyright 2005 CommerceNet Consortium, LLC.  All rights reserved.

// This software is published under the terms of the MIT license, a copy
// of which has been included with this distribution in the LICENSE file.

/** Base class for Html helper classes.  */
public interface HtmlElement {
    public void render(StringBuffer buf);
}
